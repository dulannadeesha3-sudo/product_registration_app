# Generated code do not commit.
file(TO_CMAKE_PATH "D:\\development\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\USER\\OneDrive\\Desktop\\Flutter\\product_registration_app" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=D:\\development\\flutter"
  "PROJECT_DIR=C:\\Users\\USER\\OneDrive\\Desktop\\Flutter\\product_registration_app"
  "FLUTTER_ROOT=D:\\development\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\USER\\OneDrive\\Desktop\\Flutter\\product_registration_app\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\USER\\OneDrive\\Desktop\\Flutter\\product_registration_app"
  "FLUTTER_TARGET=C:\\Users\\USER\\OneDrive\\Desktop\\Flutter\\product_registration_app\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9CVUlMRF9OQU1FPTEuMC4w,RkxVVFRFUl9CVUlMRF9OVU1CRVI9MQ==,RkxVVFRFUl9WRVJTSU9OPTMuNDcuNg==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049NWZjMzQ2ODM5Yg==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049NjkyMTM2Y2I2NQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMy41"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\USER\\OneDrive\\Desktop\\Flutter\\product_registration_app\\.dart_tool\\package_config.json"
)
