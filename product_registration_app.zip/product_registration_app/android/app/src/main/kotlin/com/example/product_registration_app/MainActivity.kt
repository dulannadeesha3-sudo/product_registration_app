package com.example.product_registration_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
