import 'package:flutter/material.dart';

class AppLogo extends StatelessWidget {
  final double size;

  const AppLogo({
    super.key,
    this.size = 80,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: const Color(0xFFE8EEFF),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Icon(
        Icons.shopping_bag_outlined,
        size: size * 0.55,
        color: const Color(0xFF3559A8),
      ),
    );
  }
}
