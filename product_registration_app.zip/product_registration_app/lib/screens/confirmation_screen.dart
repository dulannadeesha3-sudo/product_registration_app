import 'package:flutter/material.dart';
import 'welcome_screen.dart';

class ConfirmationScreen extends StatelessWidget {
  final String? userName;
  final String? userEmail;
  final dynamic product; // Oyaage product type eka (e.g., Product) mekata danna
  final int? quantity;
  final double? totalPrice;

  const ConfirmationScreen({
    super.key,
    this.userName,
    this.userEmail,
    this.product,
    this.quantity,
    this.totalPrice,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Confirmation'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.check_circle,
                color: Colors.green,
                size: 80,
              ),
              const SizedBox(height: 20),
              Text(
                userName != null ? 'Thank you, $userName!' : 'Success!',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text(
                'Product Registered Successfully!',
                style: TextStyle(fontSize: 18),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const WelcomeScreen(),
                    ),
                    (route) => false,
                  );
                },
                child: const Text('Back to Home'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}