import 'package:flutter/material.dart';

import '../models/product.dart';
import '../widgets/product_card.dart';
import 'product_detail_screen.dart';

class ProductListScreen extends StatelessWidget {
  final String userName;
  final String userEmail;

  ProductListScreen({
    super.key,
    required this.userName,
    required this.userEmail,
  });

  final List<Product> products = const [
    Product(
      id: 1,
      name: 'Wireless Headphones',
      description:
          'Comfortable wireless headphones with immersive sound.',
      price: 8500,
      imageUrl:
          'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600',
    ),
    Product(
      id: 2,
      name: 'Smart Watch',
      description:
          'A modern watch for daily activity and notifications.',
      price: 12500,
      imageUrl:
          'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600',
    ),
    Product(
      id: 3,
      name: 'Running Shoes',
      description:
          'Lightweight shoes designed for comfort and everyday use.',
      price: 9500,
      imageUrl:
          'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600',
    ),
    Product(
      id: 4,
      name: 'Backpack',
      description:
          'A practical backpack for work, study, and travel.',
      price: 6500,
      imageUrl:
          'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FC),
      appBar: AppBar(
        title: const Text('Explore Products'),
        backgroundColor: const Color(0xFFF7F8FC),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Hello, $userName!',
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF24345A),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                userEmail,
                style: const TextStyle(color: Colors.black54),
              ),
              const SizedBox(height: 22),
              const Text(
                'Our Products',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 14),
              Expanded(
                child: GridView.builder(
                  itemCount: products.length,
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 0.68,
                  ),
                  itemBuilder: (context, index) {
                    final product = products[index];

                    return ProductCard(
                      product: product,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ProductDetailScreen(
                              product: product,
                              userName: userName,
                              userEmail: userEmail,
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
