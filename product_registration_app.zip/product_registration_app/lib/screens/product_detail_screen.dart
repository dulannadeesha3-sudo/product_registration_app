import 'package:flutter/material.dart';

import '../models/product.dart';
import '../widgets/primary_action_button.dart';
import 'confirmation_screen.dart';
	
class ProductDetailScreen extends StatefulWidget {
  final Product product;
  final String userName;
  final String userEmail;

  const ProductDetailScreen({
    super.key,
    required this.product,
    required this.userName,
    required this.userEmail,
  });

  @override
  State<ProductDetailScreen> createState() =>
      _ProductDetailScreenState();
}

class _ProductDetailScreenState
    extends State<ProductDetailScreen> {
  int _quantity = 1;

  double get _totalPrice =>
      widget.product.price * _quantity;

  @override
  Widget build(BuildContext context) {
    final product = widget.product;

    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FC),
      appBar: AppBar(
        title: const Text('Product Details'),
        backgroundColor: const Color(0xFFF7F8FC),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                height: 240,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Image.network(
                  product.imageUrl,
                  fit: BoxFit.contain,
                  errorBuilder: (_, error, stackTrace) {
                    return const Icon(
                      Icons.shopping_bag_outlined,
                      size: 100,
                      color: Color(0xFF3559A8),
                    );
                  },
                ),
              ),
              const SizedBox(height: 24),
              Text(
                product.name,
                style: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF24345A),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'LKR ${product.price.toStringAsFixed(2)}',
                style: const TextStyle(
                  fontSize: 22,
                  color: Color(0xFF3559A8),
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 18),
              Text(
                product.description,
                style: const TextStyle(
                  fontSize: 16,
                  height: 1.6,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 28),

              const Text(
                'Select Quantity',
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 12),

              Row(
                children: [
                  IconButton.filledTonal(
                    onPressed: _quantity > 1
                        ? () {
                            setState(() {
                              _quantity--;
                            });
                          }
                        : null,
                    icon: const Icon(Icons.remove),
                  ),
                  const SizedBox(width: 20),
                  Text(
                    '$_quantity',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(width: 20),
                  IconButton.filledTonal(
                    onPressed: () {
                      setState(() {
                        _quantity++;
                      });
                    },
                    icon: const Icon(Icons.add),
                  ),
                ],
              ),

              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: const Color(0xFFE8EEFF),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'Total price',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Text(
                      'LKR ${_totalPrice.toStringAsFixed(2)}',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: Color(0xFF24345A),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              PrimaryActionButton(
                text: 'Confirm Selection',
                icon: Icons.check_circle_outline,
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ConfirmationScreen(
                        userName: widget.userName,
                        userEmail: widget.userEmail,
                        product: product,
                        quantity: _quantity,
                        totalPrice: _totalPrice,
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
